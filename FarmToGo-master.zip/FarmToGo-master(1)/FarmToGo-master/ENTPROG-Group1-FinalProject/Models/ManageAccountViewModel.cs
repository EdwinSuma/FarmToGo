﻿namespace Farmers.App.Models
{
    public class ManageAccountViewModel
    {
        public string FullName { get; set; }

        public string Email { get; set; }
    }
}

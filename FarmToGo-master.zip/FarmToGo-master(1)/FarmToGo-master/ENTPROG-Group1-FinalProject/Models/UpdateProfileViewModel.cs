﻿namespace Farmers.App.Models
{
    public class UpdateProfileViewModel
    {
        public string FullName { get; set; }

        public string Email { get; set; }
    }
}
